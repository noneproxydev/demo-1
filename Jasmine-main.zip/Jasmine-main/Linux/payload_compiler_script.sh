go mod tidy
go mod download

export GO111MODULE=auto
mkdir ./built

export GOOS=linux

export GOARCH=arm
go build -ldflags "-s -w" -o ./built/linux_arm Linux/client
export GOARCH=arm64
go build -ldflags "-s -w" -o ./built/linux_arm64 Linux/client
export GOARCH=386
go build -ldflags "-s -w" -o ./built/linux_i386 Linux/client
export GOARCH=amd64
go build -ldflags "-s -w" -o ./built/linux_amd64 Linux/client



./statik -m -src="./built" -f -dest="./server/embed" -include=* -p built -ns built
