echo "Don't close the terminal"

apt update
apt install nodejs npm golang -y

echo "Don't close the terminal"

cd web
npm install
npm run build-prod

echo "Don't close the terminal"

cd ..
go install github.com/rakyll/statik

./statik -m -src="./web/dist" -f -dest="./server/embed" -p web -ns web
mkdir ./controller

export GOOS=linux
export GOARCH=arm
go build -ldflags "-s -w" -tags=jsoniter -o ./controller/server_linux_arm Linux/server
export GOARCH=arm64
go build -ldflags "-s -w" -tags=jsoniter -o ./controller/server_linux_arm64 Linux/server
export GOARCH=386
go build -ldflags "-s -w" -tags=jsoniter -o ./controller/server_linux_i386 Linux/server
export GOARCH=amd64
go build -ldflags "-s -w" -tags=jsoniter -o ./controller/server_linux_amd64 Linux/server
