import i18n from 'i18next';
import zhCN from './zh-CN';

const resources = {
	'zh-CN': {
		translation: zhCN
	},
};
const lang = navigator.language && navigator.language.length ? navigator.language : 'zh-CN';
const locale = resources[lang] ? lang : 'zh-CN';

i18n.init({
	lng: lang,
	fallbackLng: 'zh-CN',
	initImmediate: true,
	resources
});

function getLang() {
	return lang;
}
function getLocale() {
	return locale;
}

export { getLang, getLocale };
export default i18n;