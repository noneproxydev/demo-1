package process

import (
	"Linux/modules"
	"Linux/server/common"
	"Linux/server/handler/utility"
	"Linux/utils"
	"Linux/utils/melody"
	"github.com/gin-gonic/gin"
	"net/http"
	"time"
)

// ListDeviceProcesses will list processes on remote client
func ListDeviceProcesses(ctx *gin.Context) {
	connUUID, ok := utility.CheckForm(ctx, nil)
	if !ok {
		return
	}
	trigger := utils.GetStrUUID()
	common.SendPackByUUID(modules.Packet{Act: `PROCESSES_LIST`, Event: trigger}, connUUID)
	ok = common.AddEventOnce(func(p modules.Packet, _ *melody.Session) {
		if p.Code != 0 {
			ctx.AbortWithStatusJSON(http.StatusInternalServerError, modules.Packet{Code: 1, Msg: p.Msg})
		} else {
			ctx.JSON(http.StatusOK, modules.Packet{Code: 0, Data: p.Data})
		}
	}, connUUID, trigger, 5*time.Second)
	if !ok {
		ctx.AbortWithStatusJSON(http.StatusGatewayTimeout, modules.Packet{Code: 1, Msg: `${i18n|COMMON.RESPONSE_TIMEOUT}`})
	}
}

